# CSC-587-W1
# Desmond Sheppard
# Dr. Halil Bisgin

# 1) Distance Measures between objects 1 and 3. Mixed Attributes; weighted avg needed
# Data: Obj1. {"A", "excellent", 45}; Obj3. {"C", "good", 64}
# a. Nominal calculation: dissimilarity / object_count (binary match); A != C
# d(Obj1, Obj3)_nom = 1/(2-1) = 1 (fully dissimilar)
# b. Ordinal calculation: excellent = best, good = mid, fair = worst: 3 options
# Total ranks: 3; rank points: Obj1 = (3-1)/(3-1) = 1; Obj3 = (2-1)/(3-1) = 1/2
# d(Obj1, Obj3)_ord = 1 - (1/2) = 1/2 (about as different as similar)
# c. Numerical calculation: normalized data (simplified): abs_val_difference / max_range
# max_range = 64-22 = 42
# d(Obj1, Obj3)_num = (|45-64|)/42 = 19/42 (approx. 0.45238)
# d(Obj1, Obj3) (Minkowski L1 "Manhattan") = |1|+|1/2|+|19/42| = 82/42 (approx. 1.95238)
# d(Obj1, Obj3) (Minkowski L2 "Euclid") = (1^2 +(1/2)^2 +(19/42)^2)^(1/2) = 1.70238 (approx.)
# d(Obj1, Obj3) (Minkowski L-inf "Supremum/Chebyshev") = lim(p->inf) (1^p + (1/2)^p + (19/42)^p)^(1/p)
#    = max(d_nom, d_ord, d_num) = max(1, 1/2, 19/42) = 1
# Takeaway: Supremum is smallest; Manhattan is largest

# 2) See PDF and .cpp file.

# 3) Chi-squared test for data in table to answer "Is there dependency between attendance
#    in class and passing?"
# Calc: sum(sq(observed - expected))/expected (obs: table values; exp: calculated)
# Expected Value Calculation: (|sum_var1|*|sum_var2|)/abs_total
# E(attend-pass) = (31*33)/54 = 1023/54 = 341/18 (approx. 18.94444)
# E(attend-fail) = (31*21)/54 = 651/54 = 217/18 (approx. 12.05555)
# E(skip-pass) = (23*33)/54 = 759/54 = 253/18 (approx. 14.05555)
# E(skip-fail) = (23*21)/54 = 483/54 = 161/18 (approx. 8.94444)
# The following calculations are z-scores! They use expected value to approximate means.
# Chi-sq(attend-pass) = sq(25-341/18)/(341/18) 
# Chi-sq(attend-fail) = sq(6-217/18)/(217/18)
# Chi-sq(skip-pass) = sq(8-253/18)/(253/18) 
# Chi-sq(skip-fail) = sq(15-161/18)/(161/18)
# Chi-sq = sum_previous+four = 11.68602 (approx.)
# For an item with one degree of freedom, HIGHLY UNLIKELY this is uncorrelated
#    "Rejection of null hypothesis" obtained (passing strongly depends on attendance)

# 4) Correlation plot for "mpg" and "wt" components of the "mtcars" data frame:
# a. Determine correlation for the frame's data points as x="wt", y="mpg"
cor(mtcars$wt, mtcars$mpg)
# b. Plot this outcome (-0.8676594) to a scatter plot to see negative correlation
#     Note: variable names carry over automatically
plot(mtcars$wt, mtcars$mpg)

# 5) Find a code to remove data columns that have more than 75% missing values.
# Bracket notation can be used to identify a conditional subset of a dataframe.
# For reduced hard disk clutter, I am using the Google Drive library.
library(googledrive)

# import to a data frame called "metData"
metData <- read.csv(text = drive_read_string("metabolite.csv"))

# Send only columns in which the number of missing values per column doesn't
#    exceed 75% of the column's values - that is, the total number of rows:
smlMetData <- metData[colSums(is.na(metData)) < nrow(metData)*0.75]

# Calculate out all the medians, excluding NAs, and store them in a data
#    frame that replaces all remaining NAs with the respective median.
#    Note: this took a really long time to figure out but does work,
#    addressing the full column range and excluding NA values.
medianMetData <- data.frame(smlMetData)
for (i in 2:ncol(smlMetData)) {
    for (j in 1:nrow(smlMetData)) {
        if (is.na(medianMetData[j, i]))
            medianMetData[j, i] = median(smlMetData[,i], na.rm = TRUE)
    }
}

# To genericize, then, the structure is:
x <- read.csv(text = "C://data/location/on/disk")
kleenX <- x[colSums(is.na(x)) < nrow(x)*0.75]
preprocX <- data.frame(kleenX)
for (i in 2:ncol(preprocX)) {
  for (j in 1:nrow(preprocX)) {
    if (is.na(preprocX[j, i]))
      preprocX[j, i] = median(kleenX[,i], na.rm = TRUE)
  }
}

# 6. Principal Component Analysis of the data:
# initial sweep for duplicate data (safe based on boolean sweep):
uniqueMetData <- medianMetData
for (i in 1:(ncol(uniqueMetData)-1)) {
    for (j in (i+1):ncol(uniqueMetData)) {
        if (all(medianMetData[,i] == medianMetData[,j])) {
            uniqueMetData[,j] = NA
        }
    }
}
for (i in 1:(nrow(uniqueMetData)-1)) {
  for (j in (i+1):nrow(uniqueMetData)) {
    if (all(medianMetData[i,] == medianMetData[j,])) {
      sMetData[j,] = NA
    }
  }
}
# Confirmation of one duplicate-data column... repeating prior procedure for NA removal:
cleanMetData <- uniqueMetData[colSums(is.na(uniqueMetData)) < nrow(uniqueMetData)*0.75]
# a) Standardize data to ensure mean = 0 and SD = 1 (wait, that's a Z-Score...)
zScore_metData <- cleanMetData
for (i in 2:ncol(zScore_metData)) {
    for (j in 1:nrow(zScore_metData)) {
        zScore_metData[j, i] =
            (cleanMetData[j, i] - mean(cleanMetData[,i]))/sd(cleanMetData[,i])
    }
}
# Note: I later learned that scale() does exactly this... oh well.
# b) Assess correlations via covariance, remembering that negative relationships are
#    "inverse related" and not "less related":
corrMetData <- cov(zScore_metData[,2:187])
# Determine maximum positively and negatively correlated components (omitting the
#    diagonal identity/variance for the maximum):
maxlist <- data.frame(sapply(corrMetData, nth, 2, descending = TRUE))
minlist <- data.frame(sapply(corrMetData, nth, 1))
#    Strongest "hard" correlations are to PC.aa.C34.3 (phosphatidylcholine diacyl C34:3:
#    0.9952903, positive) and Kynurenine (-0.5989792, negative).
# c) Assess eigenvalues and eigenvectors of the correlation matrix: eigenvectors are the
#    angular components of the vectors (thence, "rotation")...
eVectors = prcomp(zScore_metData[,2:187])$rotation
#    ...while the eigenvalues are the respective transformation coefficients, the
#    squares of the projected distances (sdev) from the origin.
eValues = prcomp(zScore_metData[,2:187])$sdev^2
#    The "scores" in the "$x" column are the weighted values when applying the rotation
#    matrix to the AVERAGE of the CENTERED data matrix. Z-Scores both center and
#    standardize to avoid the problem of over-weighting factors and, because the
#    calculation is already centered such that the mean is 0, the rotated matrix
#    obtained by sweep(zScore_metData[,2:187]), 2, colMeans(zScore_metData[,2:187])
#    will end up trivially returning 0.
# d) Assess principal components and extent of importance:
summary(prcomp(cov(zScore_metData[,2:187])))
# e) Develop scatter plot of Principal Components 1 and 2 relative to their Label. NOTE:
#    These plots cover both the relatively well-correlated components and the Principal
#    Components.
ggplot(as.data.frame(zScore_metData[,2:187]),
    data = zScore_metData,
    mapping = aes(x=PC.aa.C34.3, y=Kynurenine)) +
  geom_point(aes(color=Label)) +
  labs(title = 'Direct Measure of Principal Components') +
  geom_abline(slope=prcomp(zScore_metData[,2:187])$rotation[1, 2]
              / prcomp(zScore_metData[,2:187])$rotation[1, 1], color="red") +
  geom_abline(slope=prcomp(zScore_metData[,2:187])$rotation[2, 2]
              / prcomp(zScore_metData[,2:187])$rotation[2, 1], color="blue") +
  coord_fixed(ratio = 1)
ggplot(as.data.frame(prcomp(zScore_metData[,2:187])$x),
       data = as.data.frame(prcomp(zScore_metData[,2:187])$x),
       mapping = aes(x=PC1, y=PC2)) +
  geom_point(aes(color=zScore_metData$Label)) +
  labs(title = 'Direct Measure of Principal Components') +
  geom_hline(yintercept = 0, color="red") +
  geom_vline(xintercept = 0, color="blue") +
  coord_fixed(ratio = 1)