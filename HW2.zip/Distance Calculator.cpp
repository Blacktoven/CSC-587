/*  CSC 587-W1
    Desmond Sheppard
    Dr. Halil Bisgin
    Code in C++ for a Minkowski Metric Calculator
    Note: this code assumes the data is in numerical form.
*/
#include <iostream>
#include <math.h>
#include <limits>

// request the number of vectors to assess and store it
int getVectors() {
    std::cout << "Please enter the number of vectors assessed:\n";
    int vecs = 0;
    double gate = 0;
    bool lockout = true;
    while(lockout == true) {
        std::cin >> gate;
        if(std::cin.good()) {
            vecs = gate;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            lockout = false;
        } else {
            std::cout << "Enter a valid value.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
    return vecs;
}

// request the number of dimensions to assess
int getDimensions() {
    std::cout << "Please enter the number of dimensions assessed:\n";
    int dims = 0;
    double gate = 0;
    bool lockout = true;
    while(lockout == true) {
        std::cin >> gate;
        if(std::cin.good()) {
            dims = gate;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            lockout = false;
        } else {
            std::cout << "Enter a valid value.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
    return dims;
}

// establish a class from which to derive compared objects
class Object {
public:
    std::string name;
    double data[];
    setData(int vecs) {
        std::cout << "Assign a name to this object: ";
        std::string name;
        std::cin >> name;
        std::cin.clear();
        std::cout << "Note: this program is designed to work with numerical data points. Please use numbers only.\n";
        for(int i=0; i<vecs; i++) {
            std::cout << "Enter the data for vector " << i+1 << " of object " << name << ".\n";
            data[i] = 0;
            double gate = 0;
            bool lockout = true;
            while(lockout == true) {
                std::cin >> gate;
                if(std::cin.good()) {
                    data[i] = gate;
                    std::cin.clear();
                    lockout = false;
                } else {
                    std::cout << "Enter a valid value.\n";
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                }
            }
        }
    }
    ~Object() {}
};

// iterative sum function
double finalVectorSum(double finalVecs[], int vecs) {
    double dimSum = 0;
    for(int i=0; i<vecs; i++) {
        dimSum += finalVecs[i];
    }
    return dimSum;
}

// check for another set of vector items to try
int checkBounce() {
    bool lockout = true;
    bool escape = false;
    while(lockout == true) {
        std::cout << "Would you like to try a new set of vectors?\n(1 - \"Yes\", 2 - \"No\".)\n";
        int gate = 0;
        std::cin >> gate;
        if(std::cin.good()) {
            switch(gate) {
                case 1:
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    lockout = false;
                    return escape;
                case 2:
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    std::cout << "Thank you for using this program! Goodbye!";
                    lockout = false;
                    escape = true;
                    return escape;
            }
        } else {
            std::cout << "Enter a valid value.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
}

// driver code follows
int main() {
    bool bounce = false;
    while(bounce == false) {
        int vecs = getVectors();
        int dims = getDimensions();
        // create the two objects to be assessed
        Object obj1;
        obj1.setData(vecs);
        Object obj2;
        obj2.setData(vecs);
        // create a storage vector to hold the magnitude differences for each vector (dimensionality applied early)
        double vectorSet[vecs];
        for(int i=0; i<vecs; i++) {
            vectorSet[i] = 0;
            vectorSet[i] = std::pow(abs(obj1.data[i] - obj2.data[i]), dims);
        }
        // calculate the dimension-rooted sum
        double dimSum = finalVectorSum(vectorSet, vecs);
        double distance = std::pow(dimSum, (1.0/dims));
        std::cout << "Based on the specified vectors, the distance between these two objects is " << distance << ".\n";
        if(dims == 1) {
            std::cout << "This is the Manhattan norm.\n";
        } else if(dims == 2) {
            std::cout << "This is the Euclidean norm.\n";
        }
        obj1.~Object();
        obj2.~Object();
        bounce = checkBounce();
    }
    return 0;
}
