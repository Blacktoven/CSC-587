# Desmond Sheppard
# CSC-587-W1
# Professor: Dr. Halil Bisgin

# Note: I am completely lost, so we'll just learn what we can!
# Lots of reliance on "help(function)" for trial-by-fire learning in environment!
# Another Note: R apparently has no multi-line comment function, so... yeah.

# 1. Use the Su_raw_matrix.txt file for the assignment.
# Note: installed the "Google Drive" library from CRAN via
#    "install.packages('googledrive')." Very convenient resource on
#    https://googledrive.tidyverse.org/ for this item.
#    First, authenticate and permit TidyVerse API access to avoid downloading:
drive_auth()

# a) Import the Su_raw_matrix.txt file into data frame "su."
# Note: this uses googledrive "drive_read_string(as_id([insert_ID]))" to pull text
#    from docs and then use this text as a source rather than the usual file draw.
#    To find IDs, use "drive_get("filename") to see the "dribble" expressing the ID.
#    The path method can work, but it won't if there are two docs with the same name!
su <- read.delim(text = drive_read_string(as_id("1w2PR4eJfc9q__66FY6Idgeogc4UIC0rN")))

# b) Take the arithmetic mean and standard deviation of column "Liver_2.CEL" in "su."
mean(su$Liver_2.CEL)
sd(su$Liver_2.CEL)

# c) Take the same mean, but for all columns in the matrix; also take column sums.
colMeans(su)
colSums(su)

# 2. Use R's random generation for the normal distribution function on 10,000 random
#    data points to plot histograms of the following standard deviations from the mean.
#    Note: First, force graphics usage:
require(graphics)

# a) Plot the random-normal with standard deviation 0.2, limiting x to [-5, 5].
hist(rnorm(10000, mean = 0, sd = 0.2), xlim = c(-5, 5))
# This plots a histogram with minimal data dispersion from the mean: "high and narrow"

# b) Do the same, but with standard deviation 0.5.
hist(rnorm(10000, mean = 0, sd = 0.5), xlim = c(-5, 5))
# This plots a histogram with greater dispersion: "shorter and wider, but still high
#    and tight."

# SD of 0 would be "ideal mean" and all values should route very near to 0: the higher
#    the standard deviation, the fewer values are clustered at the average.

# 3. This whole step involved first installing the ggplot2 library using
#    "install.packages('ggplot2')" and then importing them  via "library(ggplot2)"
# a) creates a data frame for two random-normal distributions "A" and "B" of 200
#    data points for comparative analysis (binwidth=.5 for "useful" data display);
# b) generates an overlaid histogram pair using position="identity", ensuring
#    visibility of all data with alpha=.5;
# c) generates an interleaved histogram pair using position="dodge";
# d) creates a density plot (curve plot of the peaks: colour=cond for line color);
# e) creates the same plots (fill=cond to fill with color instead of tracing);

# Check if name is unique for "diabetes_table.csv", then import using csv import:
drive_get("diabetes_train.csv")
diabetes = read.csv(text = drive_read_string(as_id("19f2tFS5BJ0e4edbLTETMz2Kwms_YMNyN")))
# You can view the table at this point if desired with "View(diabetes)"; otherwise:

# f)
#    Overlaid diabetes histograms (semitransparent fill):
ggplot(diabetes, aes(x=mass, fill=class)) + geom_histogram(binwidth=.5, alpha=.5, position="identity")
#    Interleaved diabetes histograms:
ggplot(diabetes, aes(x=mass, fill=class)) + geom_histogram(binwidth=.5, position="dodge")
#    Diabetes Density plots, line-drawn
ggplot(diabetes, aes(x=mass, colour=class)) + geom_density()
#    Diabetes Density plots with semitransparent fill
ggplot(diabetes, aes(x=mass, fill=class)) + geom_density(alpha=.3)

# 4. Read in "titanic.csv" to "passengers" data frame - direct import as the name is
#    standalone in the folder:
passengers <- read.csv(text = drive_read_string("titanic.csv"))

# using Tidyverse libraries, piping in data after "install.package("tidyverse")" and
#    "library(tidyr)" as well as "library(dplyr)" to enable correct searching:
# a) Data from "passengers" is filtered to omit "n/a" values, then summarized:
passengers %>% drop_na() %>% summary()
# b) Data from "passengers" is filtered to only display male passengers:
passengers %>% filter(Sex == "male")
# c) Data from "passengers" is filtered to show passengers who paid the most first:
passengers %>% arrange(desc(Fare))
# d) Data from "passengers" is expanded by one column "FamSize," the sum of "Parch" and
#    SibSp:
passengers %>% mutate(FamSize = Parch + SibSp)
# e) Data from "passengers" is grouped by sex, then all aggregate data points are
#    combined into an average fare "meanFare" and a sum total of survivors "numSurv":
passengers %>% group_by(Sex) %>% summarise(meanFare = mean(Fare), numSurv = sum(Survived))

# 5) Use "quantile()" function to assess the 10th, 30th, 50th, and 60th percentiles of
#    skin data probability from the "diabetes" data frame (returns a decimal from 0 to 1):
quantile(diabetes$skin, probs = c(0.1, 0.3, 0.5, 0.6))